#!/bin/bash
#Licensed under the EUPL V.1.1 
#http://joinup.ec.europa.eu/software/page/eupl/licence-eupl

echo "Copying tar"
wget http://128.130.172.215/salsa/upload/files/daas/ElasticCassandraSetup-1.0.tar.gz
tar -xzf ./ElasticCassandraSetup-1.0.tar.gz
cd ./ElasticCassandraSetup-1.0

echo "installing cassandra"
./setupCassandra.sh

echo "configuring elastic cassandra controller"
./setupElasticCassandraController.sh

echo "configuring ganglia"
cd ./gangliaPlugIns
./setupPlugIns.sh

echo "starting cassandra"
sudo -S service cassandra start

echo "starting ganglia"
sudo -S service ganglia-monitor restart