#!/bin/bash
#Licensed under the EUPL V.1.1 
#http://joinup.ec.europa.eu/software/page/eupl/licence-eupl

#eval "sed -i 's#\<export JAVA_HOME=.*#export JAVA_HOME=$CURRENT_DIR/jre1.7.0_51#' $CURRENT_DIR/Config" 

#source ./Config


. ./Config

USER_HOME='\home\ubuntu'
CURRENT_DIR=$(pwd)
 
CASSANDRA_HOME=$CURRENT_DIR/apache-cassandra-1.2.6
CASSANDRA_BIN=$CASSANDRA_HOME/bin
CASSANDRA_CONFIG=$CASSANDRA_HOME/conf



if [ -z "$HOME" ] 
  then 
      echo "HOME not specified. Using "$USER_HOME;
      HOME = $USER_HOME;
fi

#downlaod and setup Oracle JDK (works better with Cassandra)
echo "Downloading oracle jre"

wget -nv "http://128.130.172.215/salsa/upload/files/daas/jre-7-linux-x64.tar.gz"

wget --no-check-certificate --no-cookies --header "Cookie: oraclelicense=accept-securebackup-cookie"  http://download.oracle.com/otn-pub/java/jdk/7u79-b15/jdk-7u79-linux-x64.tar.gz  

echo "Untaring jre"
tar -xzf ./jdk-7u79-linux-x64.tar.gz

JAVA_HOME=$CURRENT_DIR/jre1.7.0_79

echo "Downloading cassandra"
wget -nv "http://archive.apache.org/dist/cassandra/1.2.6/apache-cassandra-1.2.6-src.tar.gz"
echo "Untaring cassandra"
tar -xzf ./apache-cassandra-1.2.6-bin.tar.gz

#put nodetool path in Config.ini of cassandra ganglia plugins
eval "sed -i 's#\<nodetool_path: =.*#nodetool_path: =$CURRENT_DIR/apache-cassandra-1.2.6/bin/nodetool#' $CURRENT_DIR/gangliaPlugIns/python_modules/Config.ini"

#echo "Deploying and Configuring Cassandra in directory \"$CURRENT_DIR\""

#read -p "Continue (y/n)?"
#[ "$REPLY" == "y" ] || exit

echo "Create directories needed by Cassandra (they are specified in /conf/cassandra.yaml)"

#Create directories needed by Cassandra (they are specified in /conf/cassandra.yaml)
sudo -S mkdir /var/lib/cassandra
sudo -S mkdir /var/lib/cassandra/data
sudo -S mkdir /var/lib/cassandra/commitlog
sudo -S mkdir /var/lib/cassandra/saved_caches

#Give access rights tot he Cassandra dirs. Sincerely, maybe less rights might work
sudo -S chmod 0777 /var/lib/cassandra
sudo -S chmod 0777 /var/lib/cassandra/data
sudo -S chmod 0777 /var/lib/cassandra/commitlog
sudo -S chmod 0777 /var/lib/cassandra/saved_caches

###########################################################################################
#Create Cassandra script in init.d such that Cassandra starts automatically after OS boot 
###########################################################################################

#sudo chmod -R +x $CASSANDRA_BIN
#sudo chmod -R +x $JAVA_HOME

#Configure init.d script
#Set user HOME directory
eval "sed -i 's#\<HOME=.*#HOME=$HOME#' $CURRENT_DIR/cassandra"

#Set user CASSANDRA HOME directory
eval "sed -i 's#\<CASSANDRA_BIN=.*#CASSANDRA_BIN=$CASSANDRA_BIN#' $CURRENT_DIR/cassandra"
eval "sed -i 's#\<CASSANDRA_HOME=.*#CASSANDRA_HOME=$CASSANDRA_HOME#' $CURRENT_DIR/cassandra"

#Set JAVA HOME directory
eval "sed -i 's#\<JAVA_HOME=.*#JAVA_HOME=$JAVA_HOME#' $CURRENT_DIR/cassandra"
eval "sed -i 's#\<JAVA=.*#JAVA=$JAVA_HOME/bin/java#' $CASSANDRA_BIN/cassandra"
eval "sed -i 's#\<JAVA=.*#JAVA=$JAVA_HOME/bin/java#' $CASSANDRA_BIN/cassandra-cli"
eval "sed -i 's#\<JAVA=.*#JAVA=$JAVA_HOME/bin/java#' $CASSANDRA_BIN/nodetool"

eval "sed -i.bak 's/rpc_port:.*/rpc_port: $CASSANDRA_RPC_PORT/' $CASSANDRA_CONFIG/cassandra.yaml" 
eval "sed -i.bak 's/storage_port:.*/storage_port: $CASSANDRA_TCP_PORT/' $CASSANDRA_CONFIG/cassandra.yaml"   
eval "sed -i.bak 's/native_transport_port:.*/native_transport_port: $CASSANDRA_NATIVE_CQL_PORT/' $CASSANDRA_CONFIG/cassandra.yaml"

MY_IP=$(eval ifconfig eth0 | grep -o 'inet addr:[0-9.]*' | grep -o [0-9.]*)
eval "sed -i.bak  's/127.0.0.1 $(eval hostname)//' /etc/hosts"
echo "127.0.0.1 $(eval hostname)" | sudo -S tee -a /etc/hosts
eval "sed -i.bak 's/listen_address:.*/listen_address: $MY_IP/' $CASSANDRA_CONFIG/cassandra.yaml"
eval "sed -i.bak 's/rpc_address:.*/rpc_address: $MY_IP/' $CASSANDRA_CONFIG/cassandra.yaml"


echo "Cassandra deployed successfully. Cassandra can be run with \"sudo service cassandra start\"."
 
