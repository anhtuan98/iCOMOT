#!/bin/bash
#Licensed under the EUPL V.1.1 
#http://joinup.ec.europa.eu/software/page/eupl/licence-eupl

source ./Config

CURRENT_DIR=$(pwd)

CASSANDRA_HOME=$CURRENT_DIR/apache-cassandra-1.2.6
CASSANDRA_BIN=$CASSANDRA_HOME/bin
CASSANDRA_CONFIG=$CASSANDRA_HOME/conf

MY_IP=`ifconfig eth0 | grep -o 'inet addr:[0-9.]*' | grep -o [0-9.]*`

# if uncommented, promts if to delete former cassandra files. needed if we want to make an existing cassandra node elastic. clearing this folder forces cassandra to take a new token when starting. otherwise it kepps old one

#echo "Delete files from /var/lib/cassandra/commitlog/ and /var/lib/cassandra/data/ as to make sure new tokens are assigned when booting the VM?"

#select REPLY in "Yes" "No" ; do

#case $REPLY in
#	'Yes' )
#          sudo -S rm -rf  /var/lib/cassandra/commitlog/*.*;
#          sudo -S rm -rf  /var/lib/cassandra/commitlog/*;
#          sudo -S rm -rf  /var/lib/cassandra/data/*.*;
#          sudo -S rm -rf  /var/lib/cassandra/data/*;
#         break;;
#        'No')
# 	 break;;
#esac
#done       

echo "installing cassandra controller"

eval "sed -i 's#\<nodetool_path: =.*#nodetool_path=$CASSANDRA_BIN/nodetool#' ./gangliaPlugIns/python_modules/Config.ini"

 
#prepare script that scales down the cluster by removing the less loaded node
eval "sed -i 's#\<CASSANDRA_BIN=.*#CASSANDRA_BIN=$CASSANDRA_BIN#' ./scaleInCluster.sh"
eval "sed -i 's#\<CASSANDRA_HOME=.*#CASSANDRA_HOME=$CASSANDRA_HOME#' ./cassandra" 
eval "sed -i 's#\./Config#$CURRENT_DIR/Config#' ./cassandra"



eval "sed -i.bak 's/- seeds:.*/- seeds: \"$MY_IP\"/' $CASSANDRA_CONFIG/cassandra.yaml"
             

#eval "sed -i 's#\<CASSANDRA_BIN=.*#CASSANDRA_BIN=$CASSANDRA_BIN#' ./createDefaultCassandraKeyspace.sh"
#eval "sed -i 's#\<CURRENT_DIR=.*#CURRENT_DIR=$CURRENT_DIR#' ./createDefaultCassandraKeyspace.sh"

sudo -S chmod +x ./scaleInCluster.sh
sudo -S cp ./scaleInCluster.sh /bin/scaleIn 

#prepare script for decomissioning node
# execute 'decomission CASSANDRA_NODE_IP' before removing Cassandra Node, to ensure proper cleanup	

#Copy script to ensure cassandra main starts automatically
sudo -S cp ./cassandra /etc/init.d/cassandra
sudo -S chmod +x /etc/init.d/cassandra
sudo -S update-rc.d cassandra defaults

            
echo "Scripts for Elastic Cassandra Cluster deployed successfully."
