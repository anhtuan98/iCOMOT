#!/bin/bash
#Licensed under the EUPL V.1.1 
#http://joinup.ec.europa.eu/software/page/eupl/licence-eupl

CASSANDRA_BIN=
JAVA_HOME=

IP=`ifconfig eth0 | grep -o 'inet addr:[0-9.]*' | grep -o [0-9.]*`

echo -n "Decomissioning Cassandra Node... "
$CASSANDRA_BIN/nodetool -h $IP decommission
