#!/bin/bash
#Licensed under the EUPL V.1.1 
#http://joinup.ec.europa.eu/software/page/eupl/licence-eupl

wget http://128.130.172.215/salsa/upload/files/daas/ElasticCassandraSetup-1.0.tar.gz
tar -xzf ./ElasticCassandraSetup-1.0.tar.gz
cd ./ElasticCassandraSetup-1.0

./setupCassandra.sh
./setupElasticCassandraNode.sh
cd ./gangliaPlugIns
./setupPlugIns.sh