#!/bin/sh

/usr/share/provi-agent/agent.sh

exit 0